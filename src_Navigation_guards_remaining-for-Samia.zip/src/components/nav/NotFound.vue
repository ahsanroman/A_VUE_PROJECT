<template>
    <h2>Page not found! Maybe view our <router-link to="/teams">Home Page</router-link></h2>
</template>