<template>
  <section>
    <base-card>
      <h2>Page not Found</h2>
      <p>
        This page is not be found - maybe check out all our
        <router-link to="/coaches">Coaches</router-link>.
      </p>
    </base-card>
  </section>
</template>
